﻿<?php include 'header.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>Under Construction</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/sw-a.css">
</head>

<body>
<div id='root'> <!-- root container setting the page size and behavior -->
	<?php showHeader("Главная", $menu);?>	
	<h1  style = "text-align:center;">Страница в стадии разработки</h1>
	<img style = "display: block; margin:auto; border: none;" src="media/under_construction.jpg"/>
</div>
<?php include 'footer.php'; ?>

</body>
</html>

