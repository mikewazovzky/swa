<div id = 'logout' style='float:right;'>
	<input type = "button" value = "Logout" onClick = "location.href='news.php?logout'" />
</div>

