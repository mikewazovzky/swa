﻿<div id='footer'>
	<p>&copy 2015-2016 <a href="http://sw-adventure.xyz">www.sw-adventure.xyz</a><strong>mailto: </strong>admin@sw-adventure.xyz</p>
</div>
