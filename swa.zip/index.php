<?php
include dirname(__FILE__).'/swa/main.php';
?>